"""Configuration settings for the password wordlist generator."""

MIN_LENGTH = 6
"""Default minimum password length."""

MAX_LENGTH = 16
"""Default maximum password length."""

OUTPUT_FILE = "wordlist.txt"
"""Default output file name for the generated wordlist."""


