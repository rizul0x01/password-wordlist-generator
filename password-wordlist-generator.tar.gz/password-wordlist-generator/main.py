import argparse
import os
import logging
from core.combiner import Combiner
from core.leet import Leet
from core.writer import Writer
from core.profile_loader import ProfileLoader
import config

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

def print_header():
    GREEN = "\033[92m"
    RESET = "\033[0m"
    header = f"""{GREEN}
+-------------------------------------------------------------------+
|   P|A|S|S|W|O|R|D| |W|O|R|D|L|I|S|T| |G|E|N|E|R|A|T|O|R| |v1.0|   |
+-------------------------------------------------------------------+
|                       [ by rizulo0x01 ]                           |
+-------------------------------------------------------------------+
{RESET}"""
    print(header)

def main():
    """Main function to parse arguments, generate wordlist, and write to file."""
    print_header()
    parser = argparse.ArgumentParser(description="Advanced Targeted Password Wordlist Generator")
    parser.add_argument("-m", "--manual", action="store_true", help="Enable manual input mode")
    parser.add_argument("-p", "--profile", type=str, help="Path to a JSON profile for data loading")
    parser.add_argument("-o", "--output", type=str, default=config.OUTPUT_FILE, help="Output file name")
    parser.add_argument("--min-length", type=int, default=config.MIN_LENGTH, help="Minimum password length")
    parser.add_argument("--max-length", type=int, default=config.MAX_LENGTH, help="Maximum password length")

    args = parser.parse_args()

    combiner = Combiner(min_length=args.min_length, max_length=args.max_length)
    leet = Leet()
    writer = Writer(output_file=args.output, min_length=args.min_length, max_length=args.max_length)
    profile_loader = ProfileLoader()

    data = []

    if args.manual:
        logging.info("Entering manual input mode. Please provide the following details (leave blank to skip):")

        # Personal Identity
        first_name = input("First Name: ").strip()
        if first_name: data.append(first_name)

        middle_name = input("Middle Name: ").strip()
        if middle_name: data.append(middle_name)

        last_name = input("Last Name: ").strip()
        if last_name: data.append(last_name)

        nickname = input("Nickname: ").strip()
        if nickname: data.append(nickname)

        username_email_prefix = input("Username / Email Prefix: ").strip()
        if username_email_prefix: data.append(username_email_prefix)

        # Dates
        dob = input("Date of Birth (DDMMYYYY): ").strip()
        if dob: data.append(dob)

        birth_year = input("Birth Year (e.g., 2001): ").strip()
        if birth_year: data.append(birth_year)

        anniversary_date = input("Anniversary Date (DDMMYYYY): ").strip()
        if anniversary_date: data.append(anniversary_date)

        graduation_year = input("Graduation Year: ").strip()
        if graduation_year: data.append(graduation_year)

        favorite_year = input("Favorite Year / Lucky Number (Year): ").strip()
        if favorite_year: data.append(favorite_year)

        # Emotional Anchors
        pet_name = input("Pet Name (current/previous): ").strip()
        if pet_name: data.append(pet_name)

        best_friend_name = input("Best Friend's Name: ").strip()
        if best_friend_name: data.append(best_friend_name)

        partner_spouse_name = input("Partner/Spouse Name: ").strip()
        if partner_spouse_name: data.append(partner_spouse_name)

        child_name = input("Child's Name: ").strip()
        if child_name: data.append(child_name)

        # Lifestyle & Preferences
        city_of_birth = input("City of Birth / Hometown: ").strip()
        if city_of_birth: data.append(city_of_birth)

        current_city = input("Current City: ").strip()
        if current_city: data.append(current_city)

        favorite_sports_team = input("Favorite Sports Team: ").strip()
        if favorite_sports_team: data.append(favorite_sports_team)

        favorite_color = input("Favorite Color: ").strip()
        if favorite_color: data.append(favorite_color)

        favorite_actor_actress = input("Favorite Actor/Actress: ").strip()
        if favorite_actor_actress: data.append(favorite_actor_actress)

        favorite_movie_game = input("Favorite Movie or Game: ").strip()
        if favorite_movie_game: data.append(favorite_movie_game)

        school_college_name = input("School/College Name: ").strip()
        if school_college_name: data.append(school_college_name)

        # Numeric Anchors
        lucky_numbers = input("Lucky Numbers (comma-separated, e.g., 7,13): ").strip()
        if lucky_numbers:
            data.extend([num.strip() for num in lucky_numbers.split(",") if num.strip()])

        mobile_number_partial = input("Mobile Number (partial, e.g., last 4 digits): ").strip()
        if mobile_number_partial: data.append(mobile_number_partial)

        postal_code = input("Postal Code (PIN): ").strip()
        if postal_code: data.append(postal_code)

        favorite_number_sequences = input("Favorite Number Sequences (comma-separated, e.g., 123,007): ").strip()
        if favorite_number_sequences:
            data.extend([seq.strip() for seq in favorite_number_sequences.split(",") if seq.strip()])

        # User-defined Custom Words
        logging.info("Enter any Special Words / Phrases (one per line, type 'done' to finish):")
        while True:
            special_word = input("Special Word: ").strip()
            if special_word.lower() == 'done':
                break
            if special_word: data.append(special_word)

        logging.info("Enter any Tags / Hashtags They Use (one per line, type 'done' to finish):")
        while True:
            tag = input("Tag/Hashtag: ").strip()
            if tag.lower() == 'done':
                break
            if tag: data.append(tag)

        logging.info("Enter any Keyboard Patterns (one per line, type 'done' to finish):")
        while True:
            keyboard_pattern = input("Keyboard Pattern: ").strip()
            if keyboard_pattern.lower() == 'done':
                break
            if keyboard_pattern: data.append(keyboard_pattern)

    elif args.profile:
        profile_data = profile_loader.load_profile(args.profile)
        if profile_data:
            for key, value in profile_data.items():
                if isinstance(value, list):
                    data.extend(value)
                else:
                    data.append(str(value))
    else:
        logging.error("Please use either --manual or --profile to provide input data.")
        return

    # Generate combinations using the Combiner class
    combined_words = combiner.generate_combinations(data)

    # Apply leetspeak transformations
    generated_words = set()
    for word in combined_words:
        generated_words.add(word)
        generated_words.update(leet.to_leet(word))

    # Filter by length and write to file
    final_wordlist = [word for word in generated_words if args.min_length <= len(word) <= args.max_length]
    writer.write_wordlist(sorted(list(final_wordlist)))
    logging.info(f"Wordlist generated and saved to {args.output} with {len(final_wordlist)} entries.")

if __name__ == "__main__":
    main()


