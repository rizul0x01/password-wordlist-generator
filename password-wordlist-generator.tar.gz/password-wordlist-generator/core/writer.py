class Writer:
    """Handles writing generated wordlists to a file."""
    def __init__(self, output_file="wordlist.txt", min_length=0, max_length=100):
        """Initializes the Writer with output file path and length constraints.

        Args:
            output_file (str): The path to the output file.
            min_length (int): Minimum length of passwords to write.
            max_length (int): Maximum length of passwords to write.
        """
        self.output_file = output_file
        self.min_length = min_length
        self.max_length = max_length

    def write_wordlist(self, wordlist):
        """Writes a list of words to the output file, applying length filtering.

        Args:
            wordlist (list): A list of words to be written to the file.
        """
        with open(self.output_file, "w") as f:
            for word in wordlist:
                if self.min_length <= len(word) <= self.max_length:
                    f.write(word + "\n")


