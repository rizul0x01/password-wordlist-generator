class Leet:
    """Handles Leetspeak transformations of words."""
    def __init__(self):
        """Initializes the Leet class with a mapping of characters to their Leetspeak equivalents."""
        self.leet_map = {
            'a': ['4', '@'], 'e': ['3'], 'i': ['1', '!'], 'o': ['0'],
            's': ['5', '$'], 't': ['7', '+'], 'l': ['1'], 'g': ['9'],
            'b': ['8'], 'z': ['2']
        }

    def to_leet(self, word):
        """Converts a given word into its Leetspeak variations.

        Args:
            word (str): The word to convert.

        Returns:
            list: A list of unique Leetspeak variations of the word.
        """
        variations = [""]
        for char in word.lower():
            new_variations = []
            if char in self.leet_map:
                for var in variations:
                    for leet_char in self.leet_map[char]:
                        new_variations.append(var + leet_char)
            else:
                for var in variations:
                    new_variations.append(var + char)
            variations = new_variations
        return list(set(variations))


