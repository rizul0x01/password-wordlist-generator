import json
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

class ProfileLoader:
    """Loads and validates user profile data from a JSON file."""
    REQUIRED_KEYS = [
        "first_name", "middle_name", "last_name", "nickname", "username_email_prefix",
        "dob", "birth_year", "anniversary_date", "graduation_year", "favorite_year",
        "pet_name", "best_friend_name", "partner_spouse_name", "child_name",
        "city_of_birth", "current_city", "favorite_sports_team", "favorite_color",
        "favorite_actor_actress", "favorite_movie_game", "school_college_name",
        "lucky_numbers", "mobile_number_partial", "postal_code", "favorite_number_sequences",
        "special_words", "tags_hashtags", "keyboard_patterns"
    ]

    def load_profile(self, profile_path):
        """Loads profile data from the specified JSON file.

        Args:
            profile_path (str): The path to the JSON profile file.

        Returns:
            dict or None: The loaded profile data if successful, None otherwise.
        """
        try:
            with open(profile_path, 'r') as f:
                profile_data = json.load(f)
            logging.info(f"Loaded profile data: {profile_data}")
            if self.validate_profile(profile_data):
                return profile_data
            else:
                logging.warning("Profile validation failed. Some data might be missing.")
                return profile_data # Return data even if validation fails, with a warning
        except FileNotFoundError:
            logging.error(f"Profile file not found at {profile_path}")
            return None
        except json.JSONDecodeError:
            logging.error(f"Invalid JSON in profile file at {profile_path}")
            return None

    def validate_profile(self, profile_data):
        """Validates the loaded profile data against required keys.

        Args:
            profile_data (dict): The profile data to validate.

        Returns:
            bool: True if all required keys are present, False otherwise.
        """
        missing = [key for key in self.REQUIRED_KEYS if key not in profile_data]
        if missing:
            logging.warning(f"Missing keys in profile: {', '.join(missing)}")
            return False
        return True


