class Combiner:
    """Generates password combinations based on input data and length constraints."""
    def __init__(self, min_length=0, max_length=100):
        """Initializes the Combiner with minimum and maximum password lengths.

        Args:
            min_length (int): The minimum length for generated passwords.
            max_length (int): The maximum length for generated passwords.
        """
        self.min_length = min_length
        self.max_length = max_length

    def generate_combinations(self, data):
        """Generates password combinations from the provided data.

        This method creates various combinations by appending numbers, special characters,
        and combining elements from the input data, and also applies length filtering.

        Args:
            data (list): A list of strings or other data to combine.

        Returns:
            set: A set of generated password combinations.
        """
        combinations = set()
        numbers = ["1", "123", "2023", "2024", "2025"]
        special_chars = ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_", "+", "=", "~", "`", ";", ":", ",", ".", "/", "?", "|", "{", "}", "[", "]", "<", ">", "\\"]
        common_suffixes = ["1", "123", "!", "@", "#", "$", "*", "_", "-", ".", "01", "07", "14", "21", "24", "25", "786", "007", "143"]
        years = [str(y) for y in range(1980, 2026)] # Generate years from 1980 to 2025

        # Ensure all data items are strings
        data = [str(item) for item in data if item]

        # Add original items
        for item in data:
            combinations.add(item)
            combinations.add(item.lower())
            combinations.add(item.capitalize())

        # Combinations with numbers and special characters
        for item in data:
            for num in numbers:
                combinations.add(item + num)
                combinations.add(item.lower() + num)
                combinations.add(item.capitalize() + num)
            for char in special_chars:
                combinations.add(item + char)
                combinations.add(item.lower() + char)
                combinations.add(item.capitalize() + char)
            for num in numbers:
                for char in special_chars:
                    combinations.add(item + num + char)
                    combinations.add(item.lower() + num + char)
                    combinations.add(item.capitalize() + num + char)
                    combinations.add(item + char + num)
                    combinations.add(item.lower() + char + num)
                    combinations.add(item.capitalize() + char + num)

        # Combinations of two data items
        for i in range(len(data)):
            for j in range(i + 1, len(data)):
                item1 = data[i]
                item2 = data[j]

                # Direct combinations
                combinations.add(item1 + item2)
                combinations.add(item1.lower() + item2.lower())
                combinations.add(item1.capitalize() + item2.capitalize())

                # Combinations with separators
                for sep in ["_", "-", ".", " "]:
                    combinations.add(item1 + sep + item2)
                    combinations.add(item1.lower() + sep + item2.lower())
                    combinations.add(item1.capitalize() + sep + item2.capitalize())

                # Combinations with years
                for year in years:
                    combinations.add(item1 + item2 + year)
                    combinations.add(item1.lower() + item2.lower() + year)
                    combinations.add(item1.capitalize() + item2.capitalize() + year)
                    combinations.add(item1 + year + item2)
                    combinations.add(item1.lower() + year + item2.lower())
                    combinations.add(item1.capitalize() + year + item2.capitalize())

                # Combinations with common suffixes
                for suffix in common_suffixes:
                    combinations.add(item1 + item2 + suffix)
                    combinations.add(item1.lower() + item2.lower() + suffix)
                    combinations.add(item1.capitalize() + item2.capitalize() + suffix)

        # Combinations with years and common suffixes for single items
        for item in data:
            for year in years:
                combinations.add(item + year)
                combinations.add(item.lower() + year)
                combinations.add(item.capitalize() + year)
            for suffix in common_suffixes:
                combinations.add(item + suffix)
                combinations.add(item.lower() + suffix)
                combinations.add(item.capitalize() + suffix)

        # Filter by length
        final_combinations = set()
        for combo in combinations:
            if self.min_length <= len(combo) <= self.max_length:
                final_combinations.add(combo)

        return final_combinations


