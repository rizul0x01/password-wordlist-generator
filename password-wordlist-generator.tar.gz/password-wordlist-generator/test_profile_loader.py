import unittest
import json
import os
from core.profile_loader import ProfileLoader

class TestProfileLoader(unittest.TestCase):

    def setUp(self):
        self.profile_loader = ProfileLoader()
        self.test_profile_path = "test_temp_profile.json"

    def tearDown(self):
        if os.path.exists(self.test_profile_path):
            os.remove(self.test_profile_path)

    def _create_test_profile(self, data):
        with open(self.test_profile_path, "w") as f:
            json.dump(data, f)

    def test_load_profile_success(self):
        test_data = {"name": "John", "dob": "1990", "pet": "Max", "keywords": ["test"]}
        self._create_test_profile(test_data)
        loaded_data = self.profile_loader.load_profile(self.test_profile_path)
        self.assertEqual(loaded_data, test_data)

    def test_load_profile_file_not_found(self):
        loaded_data = self.profile_loader.load_profile("non_existent_file.json")
        self.assertIsNone(loaded_data)

    def test_load_profile_invalid_json(self):
        with open(self.test_profile_path, "w") as f:
            f.write("invalid json")
        loaded_data = self.profile_loader.load_profile(self.test_profile_path)
        self.assertIsNone(loaded_data)

    def test_validate_profile_success(self):
        valid_data = {"name": "John", "dob": "1990", "pet": "Max", "keywords": ["test"]}
        self.assertTrue(self.profile_loader.validate_profile(valid_data))

    def test_validate_profile_missing_keys(self):
        invalid_data = {"name": "John", "dob": "1990"}
        self.assertFalse(self.profile_loader.validate_profile(invalid_data))

if __name__ == '__main__':
    unittest.main()


